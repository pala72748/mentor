import React from 'react'
import Header from '../Header/Header'
import banner from "../../assets/banner.png";
import student from "../../assets/student.png";
import user from "../../assets/user.png";
import search from "../../assets/search.png";
import laptop from "../../assets/laptop.png";
import graduate from "../../assets/graduate.png";
import { LiaUserFriendsSolid } from "react-icons/lia";
import { FaPlay } from "react-icons/fa";
import person from "../../assets/person.png";


const Home = () => {
    return (
        <>
            <Header />
            <div className='mx-auto flex max-w-7xl items-center justify-between p-6 lg:px-8 h-screen'>
                <div>
                    <h2 className='text-7xl mb-8 font-bold	'>Learn a new skill <br></br>with Kjxsoftech</h2>
                    <p className='text-2xl'>Acquire a new skill, initiate a project, and achieve <br /> your desired career path.</p>
                    <div className="hidden lg:flex lg:flex-1 lg:justify-start mt-10">
                        <button class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-9 rounded ">
                            Find Your Mentor
                        </button>
                        <button class=" text-black font-bold py-2 px-4 rounded mx-2">
                            Become a Mentor
                        </button>
                    </div>
                    <div className='my-6 flex items-center'>
                        <img src={student} alt="" />
                        <div className='mx-5'>
                            <h2 className='text-xl font-semibold'>250K</h2>
                            <p>HAPPY STUDENTS</p>
                        </div>
                    </div>
                </div>
                <div>
                    <img className="h-auto w-[500px]" src={banner} alt="" />
                </div>
            </div>
            <div className='container mx-auto p-6'>
                <div className='text-center'>
                    <h2 className='text-xl py-5'>WHY CHOOSE US</h2>
                    <p className='text-4xl mb-8 font-bold'>The Benefits You Get When <br /> You Study at Kjxsoftech</p>
                </div>
            </div>
            <div className='container mx-auto flex max-w-7xl items-center justify-between p-6'>
                <div className='flex flex-row justify-center items-center'>
                    <div className='w-[270px] m-5 '>
                        <a href="#" class="block max-w-sm p-6 border-t-4 bg-white border-[#1902fd] border-gray-200 rounded-b-lg shadow hover:bg-gray-100 dark:bg-gray-800 dark:border-gray-700 dark:hover:bg-gray-700">
                            <LiaUserFriendsSolid style={{ fontSize: 40, backgroundColor: "blue", color: "white", padding: 5, borderRadius: 5 }} />
                            <h5 class="my-6 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Experience Mentor</h5>
                            <p class="font-normal text-gray-700 dark:text-gray-400">Here are the biggest enterprise technology acquisitions of 2021 so far, in reverse chronological order.</p>
                        </a>
                    </div>
                    <div className='w-[270px] m-5'>
                        <a href="#" class="block max-w-sm p-6 bg-white border-t-4 border-[#ff0069] border-gray-200 rounded-b-lg shadow hover:bg-gray-100 dark:bg-gray-800 dark:border-gray-700 dark:hover:bg-gray-700">
                            <LiaUserFriendsSolid style={{ fontSize: 40, backgroundColor: "#ff0069", color: "white", padding: 5, borderRadius: 5 }} />
                            <h5 class="my-6 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Experience Mentor</h5>                            <p class="font-normal text-gray-700 dark:text-gray-400">Here are the biggest enterprise technology acquisitions of 2021 so far, in reverse chronological order.</p>
                        </a>
                    </div>
                    <div className='w-[270px] m-5'>
                        <a href="#" class="block max-w-sm p-6 bg-white border-t-4 border-[#ffa800] rounded-b-lg shadow hover:bg-gray-100 dark:bg-gray-800 dark:border-gray-700 dark:hover:bg-gray-700">
                            <LiaUserFriendsSolid style={{ fontSize: 40, backgroundColor: "#ffa800", color: "white", padding: 5, borderRadius: 5 }} />
                            <h5 class="my-6 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Experience Mentor</h5>
                            <p class="font-normal text-gray-700 dark:text-gray-400">Here are the biggest enterprise technology acquisitions of 2021 so far, in reverse chronological order.</p>
                        </a>
                    </div>
                    <div className='w-[270px] m-5'>
                        <a href="#" class="block max-w-sm p-6 bg-white border-t-4 border-[#00ff47] border-gray-200 rounded-b-lg shadow hover:bg-gray-100 dark:bg-gray-800 dark:border-gray-700 dark:hover:bg-gray-700">
                            <LiaUserFriendsSolid style={{ fontSize: 40, backgroundColor: "#00ff47", color: "white", padding: 5, borderRadius: 5 }} />
                            <h5 class="my-6 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Experience Mentor</h5>
                            <p class="font-normal text-gray-700 dark:text-gray-400">Here are the biggest enterprise technology acquisitions of 2021 so far, in reverse chronological order.</p>
                        </a>
                    </div>
                </div>
            </div>
            <div className='mx-auto flex max-w-7xl items-center justify-between p-6 lg:px-8 mt-12'>
                <div className='flex flex-row items-center '>
                    <div className='w-1/2'>
                        <img className="h-auto w-[550px]" src={user} alt="" />
                    </div>
                    <div className='w-1/2 ml-8'>
                        <h2 className='text-4xl mb-8 font-bold	'>Talented and Highly Qualified <br /> Tutors to Serve You for Online <br /> Study</h2>
                        <p className='text-xl'>Want to ace your next job interview? Successfully build your startup? Itching to learn high-demand skills? Work smart with an online mentor or coach by your side to offer expert advice and guidance to match your zeal. </p>
                        <div className='my-6 flex items-center'>
                            <img src={search} alt="" />
                            <div className='mx-5'>
                                <h2 className='text-xl font-semibold'>Find Your Mentor</h2>
                                <p>Explore our growing catalogue of experienced mentors until you find the perfect fit.</p>
                            </div>
                        </div>
                        <div className='my-6 flex items-center'>
                            <img src={laptop} alt="" />
                            <div className='mx-5'>
                                <h2 className='text-xl font-semibold'>Find Your Mentor</h2>
                                <p>Explore our growing catalogue of experienced mentors until you find the perfect fit.</p>
                            </div>
                        </div>
                        <div className='my-6 flex items-center'>
                            <img src={graduate} alt="" />
                            <div className='mx-8'>
                                <h2 className='text-xl font-semibold'>Find Your Mentor</h2>
                                <p>Explore our growing catalogue of experienced mentors until you find the perfect fit.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className='container mx-auto'>
                <div className='flex flex-col lg:flex-row items-center justify-between p-6 lg:px-8'>
                    <div className='w-full lg:w-1/2 mb-4 lg:mb-0'>
                        <h2 className="text-2xl lg:text-4xl font-semibold">Our Most Popular Courses</h2>
                        <p className="mt-2">Let’s join our best classes with our famous instructor and institutes</p>
                    </div>
                    <div className='w-full lg:w-1/2 lg:text-right'>
                        <a href="#" className="text-blue-500 hover:text-blue-700 font-semibold">Explore Courses</a>
                    </div>
                </div>
            </div>
            <div className='container mx-auto w-960 items-center'>
                <div className='flex flex-row grid lg:grid-cols-3 lg:flex-row items-center justify-between p-6 lg:px-8'>
                    <div class="max-w-sm bg-white border my-6 border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700">
                        <a href="#">
                            <img class="rounded-t-lg" src="https://as1.ftcdn.net/v2/jpg/02/27/20/72/1000_F_227207295_XnYyYPECxoQPcOTID1v3B5CFMjchJ0Ph.jpg" alt="" />
                        </a>
                        <div className='m-5 flex flex-row items-center'>
                            <FaPlay style={{ fontSize: 20, backgroundColor: "#00ff47", color: "white", padding: 5, borderRadius: 50 }} />
                            <p className='pl-4'>25x Lesson</p>

                        </div>
                        <div class="p-5">
                            <a href="#">
                                <h5 class="mb-2 text-xl font-bold tracking-tight text-gray-900 dark:text-white border-b-2 pb-6">Supervised Machine Learning: Regression and Classification</h5>
                            </a>
                            <div className='mx-auto flex flex-row flex-wrap items-center justify-between'>
                                <div className='flex flex-row my-6'>
                                    <img src={person} className='w-8 h-8' alt="" />
                                    <div className='ml-4'>
                                        <h2 className='text-[14px]  font-semibold'>Wade Warren</h2>
                                        <p className='text-[12px]'>Python Developer</p>
                                    </div>
                                </div>
                                <div className=''>
                                    <a href="#" class="inline-flex items-center px-6 py-2 text-sm font-medium text-center text-white bg-blue-700 rounded-full hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                                        Design
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="max-w-sm bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700">
                        <a href="#">
                            <img class="rounded-t-lg" src="https://as1.ftcdn.net/v2/jpg/02/27/20/72/1000_F_227207295_XnYyYPECxoQPcOTID1v3B5CFMjchJ0Ph.jpg" alt="" />
                        </a>
                        <div className='m-5 flex flex-row items-center'>
                            <FaPlay style={{ fontSize: 20, backgroundColor: "#00ff47", color: "white", padding: 5, borderRadius: 50 }} />
                            <p className='pl-4'>25x Lesson</p>

                        </div>
                        <div class="p-5">
                            <a href="#">
                                <h5 class="mb-2 text-xl font-bold tracking-tight text-gray-900 dark:text-white border-b-2 pb-6">Supervised Machine Learning: Regression and Classification</h5>
                            </a>
                            <div className='mx-auto flex flex-row flex-wrap items-center justify-between'>
                                <div className='flex flex-row my-6'>
                                    <img src={person} className='w-8 h-8' alt="" />
                                    <div className='ml-4'>
                                        <h2 className='text-[14px]  font-semibold'>Wade Warren</h2>
                                        <p className='text-[12px]'>Python Developer</p>
                                    </div>
                                </div>
                                <div className=''>
                                    <a href="#" class="inline-flex items-center px-6 py-2 text-sm font-medium text-center text-white bg-blue-700 rounded-full hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                                        Design
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="max-w-sm bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700">
                        <a href="#">
                            <img class="rounded-t-lg" src="https://as1.ftcdn.net/v2/jpg/02/27/20/72/1000_F_227207295_XnYyYPECxoQPcOTID1v3B5CFMjchJ0Ph.jpg" alt="" />
                        </a>
                        <div className='m-5 flex flex-row items-center'>
                            <FaPlay style={{ fontSize: 20, backgroundColor: "#00ff47", color: "white", padding: 5, borderRadius: 50 }} />
                            <p className='pl-4'>25x Lesson</p>

                        </div>
                        <div class="p-5">
                            <a href="#">
                                <h5 class="mb-2 text-xl font-bold tracking-tight text-gray-900 dark:text-white border-b-2 pb-6">Supervised Machine Learning: Regression and Classification</h5>
                            </a>
                            <div className='mx-auto flex flex-row flex-wrap items-center justify-between'>
                                <div className='flex flex-row my-6'>
                                    <img src={person} className='w-8 h-8' alt="" />
                                    <div className='ml-4'>
                                        <h2 className='text-[14px]  font-semibold'>Wade Warren</h2>
                                        <p className='text-[12px]'>Python Developer</p>
                                    </div>
                                </div>
                                <div className=''>
                                    <a href="#" class="inline-flex items-center px-6 py-2 text-sm font-medium text-center text-white bg-blue-700 rounded-full hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                                        Design
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="max-w-sm bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700">
                        <a href="#">
                            <img class="rounded-t-lg" src="https://as1.ftcdn.net/v2/jpg/02/27/20/72/1000_F_227207295_XnYyYPECxoQPcOTID1v3B5CFMjchJ0Ph.jpg" alt="" />
                        </a>
                        <div className='m-5 flex flex-row items-center'>
                            <FaPlay style={{ fontSize: 20, backgroundColor: "#00ff47", color: "white", padding: 5, borderRadius: 50 }} />
                            <p className='pl-4'>25x Lesson</p>

                        </div>
                        <div class="p-5">
                            <a href="#">
                                <h5 class="mb-2 text-xl font-bold tracking-tight text-gray-900 dark:text-white border-b-2 pb-6">Supervised Machine Learning: Regression and Classification</h5>
                            </a>
                            <div className='mx-auto flex flex-row flex-wrap items-center justify-between'>
                                <div className='flex flex-row my-6'>
                                    <img src={person} className='w-8 h-8' alt="" />
                                    <div className='ml-4'>
                                        <h2 className='text-[14px]  font-semibold'>Wade Warren</h2>
                                        <p className='text-[12px]'>Python Developer</p>
                                    </div>
                                </div>
                                <div className=''>
                                    <a href="#" class="inline-flex items-center px-6 py-2 text-sm font-medium text-center text-white bg-blue-700 rounded-full hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                                        Design
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="max-w-sm bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700">
                        <a href="#">
                            <img class="rounded-t-lg" src="https://as1.ftcdn.net/v2/jpg/02/27/20/72/1000_F_227207295_XnYyYPECxoQPcOTID1v3B5CFMjchJ0Ph.jpg" alt="" />
                        </a>
                        <div className='m-5 flex flex-row items-center'>
                            <FaPlay style={{ fontSize: 20, backgroundColor: "#00ff47", color: "white", padding: 5, borderRadius: 50 }} />
                            <p className='pl-4'>25x Lesson</p>

                        </div>
                        <div class="p-5">
                            <a href="#">
                                <h5 class="mb-2 text-xl font-bold tracking-tight text-gray-900 dark:text-white border-b-2 pb-6">Supervised Machine Learning: Regression and Classification</h5>
                            </a>
                            <div className='mx-auto flex flex-row flex-wrap items-center justify-between'>
                                <div className='flex flex-row my-6'>
                                    <img src={person} className='w-8 h-8' alt="" />
                                    <div className='ml-4'>
                                        <h2 className='text-[14px]  font-semibold'>Wade Warren</h2>
                                        <p className='text-[12px]'>Python Developer</p>
                                    </div>
                                </div>
                                <div className=''>
                                    <a href="#" class="inline-flex items-center px-6 py-2 text-sm font-medium text-center text-white bg-blue-700 rounded-full hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                                        Design
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="max-w-sm bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700">
                        <a href="#">
                            <img class="rounded-t-lg" src="https://as1.ftcdn.net/v2/jpg/02/27/20/72/1000_F_227207295_XnYyYPECxoQPcOTID1v3B5CFMjchJ0Ph.jpg" alt="" />
                        </a>
                        <div className='m-5 flex flex-row items-center'>
                            <FaPlay style={{ fontSize: 20, backgroundColor: "#00ff47", color: "white", padding: 5, borderRadius: 50 }} />
                            <p className='pl-4'>25x Lesson</p>

                        </div>
                        <div class="p-5">
                            <a href="#">
                                <h5 class="mb-2 text-xl font-bold tracking-tight text-gray-900 dark:text-white border-b-2 pb-6">Supervised Machine Learning: Regression and Classification</h5>
                            </a>
                            <div className='mx-auto flex flex-row flex-wrap items-center justify-between'>
                                <div className='flex flex-row my-6'>
                                    <img src={person} className='w-8 h-8' alt="" />
                                    <div className='ml-4'>
                                        <h2 className='text-[14px]  font-semibold'>Wade Warren</h2>
                                        <p className='text-[12px]'>Python Developer</p>
                                    </div>
                                </div>
                                <div className=''>
                                    <a href="#" class="inline-flex items-center px-6 py-2 text-sm font-medium text-center text-white bg-blue-700 rounded-full hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                                        Design
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Home