import Home from "./components/Pages/Home";


function App() {
  return (
    <>
      <Home/>
    </>
  )
}

export default App
